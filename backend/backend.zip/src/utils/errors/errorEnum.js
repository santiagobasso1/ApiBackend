export const ErrorEnum = {
    UNHANDLED_ERROR:0,
    ROUTING_ERROR: 1,
    INVALID_TYPES_ERROR: 2,
    DATABASE_ERROR: 3,
    MISSING_FIELDS: 4
}